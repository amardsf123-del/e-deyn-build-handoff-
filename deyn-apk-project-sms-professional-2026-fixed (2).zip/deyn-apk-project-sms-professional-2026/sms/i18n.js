const DEYN_FR_DICT = {
  "({} زبائن)": "({} clients)",
  "(⚠️ متأخر {} يوم)": "(⚠️ en retard de {} jour(s))",
  "*DEYN — كشف حساب*": "*DEYN — Relevé de compte*",
  "*الباقي عليك: {} دج*": "*Reste à payer : {} DA*",
  "+ إضافة فئة جديدة": "+ Ajouter une catégorie",
  "+ السلعة الجديدة:": "+ Nouvel article :",
  "+ زبون": "+ Client",
  "+ زبون جديد": "+ Nouveau client",
  "+ فئة جديدة": "+ Nouvelle catégorie",
  "- المبلغ المسدد:": "- Montant payé :",
  "0 دج": "0 DA",
  "0 دج (اختياري)": "0 DA (optionnel)",
  "0 زبائن": "0 client",
  "CHECK — آخر العمليات": "CHECK — Dernières opérations",
  "DEYN — تسيير الديون بكل سهولة": "DEYN — Gérez vos dettes en toute simplicité",
  "DEYN • الإصدار 1.0.0": "DEYN • Version 1.0.0",
  "DEYN: اختبار SMS ناجح - {}": "DEYN : Test SMS réussi - {}",
  "MU: المبلغ ثم × ثم نسبة الربح ثم MU": "MU : montant, puis ×, puis marge, puis MU",
  "{} • {} دج • {}": "{} • {} DA • {}",
  "{} • الاستحقاق {} • تمديد {}": "{} • Échéance {} • Prolongation {}",
  "{} • الاستحقاق {}": "{} • Échéance {}",
  "• الاستحقاق {}": "• Échéance {}",
  "• تمديد {}": "• Prolongation {}",
  "الاستحقاق": "Échéance",
  "تمديد": "Prolongation",
  "{} دج": "{} DA",
  "{} دج (دفع زائد)": "{} DA (trop-perçu)",
  "{} دج {}": "{} DA {}",
  "{} زبائن": "{} clients",
  "{} زبائن متأخرون": "{} client(s) en retard",
  "{} زبائن و {} تذاكر معلقة": "{} client(s) et {} ticket(s) en attente",
  "{} زبون": "{} client(s)",
  "{} زبون • تسديد في موعده": "{} client(s) • paiement à l'échéance",
  "{} عليه {} دج. سيُنقل حسابه إلى سلة المهملات ويمكنك استرجاعه في أي وقت.": "{} doit {} DA. Son compte sera déplacé vers la corbeille et vous pourrez le restaurer à tout moment.",
  "{} عنصر محذوف": "{} élément(s) supprimé(s)",
  "· ترحيل فوري للمبالغ إلى الزبائن": "· Transfert immédiat des montants aux clients",
  "؟": "?",
  "آخر العمليات:": "Dernières opérations :",
  "آخر خطأ:": "Dernière erreur :",
  "آخر نجاح: {} • بانتظار الإرسال: {}{}": "Dernier succès : {} • en attente d'envoi : {}{}",
  "آلة حاسبة": "Calculatrice",
  "أدخل المبلغ المسدد أو سلعة جديدة": "Saisissez le montant payé ou un nouvel article",
  "أدخل رقم هاتف صحيحًا": "Saisissez un numéro de téléphone valide",
  "أدخل كلمة المرور الحالية ثم الجديدة.": "Saisissez le mot de passe actuel puis le nouveau.",
  "أدخل كلمة المرور...": "Saisissez le mot de passe...",
  "أدخل كلمة مرور المالك لتفعيل الصلاحيات الكاملة:": "Saisissez le mot de passe du propriétaire pour activer les droits complets :",
  "أدخل مبلغ التسديد أولاً قبل تمديد الموعد": "Saisissez d'abord le montant payé avant de prolonger l'échéance",
  "أدخل مبلغًا أكبر من صفر": "Saisissez un montant supérieur à zéro",
  "أدخل مبلغًا صحيحًا": "Saisissez un montant valide",
  "أرسل معرّف هذا الجهاز إلى الدعم الفني ليصدر لك كود استرداد موقّع. الكود صالح لهذا الجهاز فقط ولمرة واحدة، ولا يغيّر ترخيصك ولا دورك ولا بياناتك.": "Envoyez l'identifiant de cet appareil au support technique pour obtenir un code de récupération signé. Le code est valable pour cet appareil uniquement et une seule fois, et ne modifie ni votre licence, ni votre rôle, ni vos données.",
  "أسابيع": "Semaines",
  "أشهر": "Mois",
  "أصوات النقر": "Sons des touches",
  "أمين سعدون": "Amine Saadoun",
  "أوراق نقدية": "Billets de banque",
  "أي زبون أو تذكرة أو بيانات تحذفها ستجدها هنا لاسترجاعها أو حذفها نهائياً.": "Tout client, ticket ou donnée que vous supprimez se trouve ici pour être restauré ou supprimé définitivement.",
  "أيام": "jours",
  "إجمالي الأموال المسددة (السيولة المحصلة)": "Total des sommes payées (trésorerie encaissée)",
  "إجمالي الديون المتأخرة:": "Total des dettes en retard :",
  "إجمالي ديون المنضبطين:": "Total des dettes des clients ponctuels :",
  "إدارة كلمة المرور": "Gérer le mot de passe",
  "إدارة وتعديل الفئات": "Gérer et modifier les catégories",
  "إدارة وحذف الفئات": "Gérer et supprimer les catégories",
  "إذا تركته فارغًا فلن تُرسل تذكيرات تلقائية لهذا الدين حتى تحدد موعدًا. الزبائن ذوو يوم السداد الشهري يحصلون على الموعد التالي تلقائيًا.": "Si laissé vide, aucun rappel automatique ne sera envoyé pour cette dette tant qu'une échéance n'est pas définie. Les clients ayant un jour de paie mensuel reçoivent automatiquement la prochaine échéance.",
  "إذا حُدد اليوم يُنبهك التطبيق عند اقتراب أو تأخر موعد السداد.": "Si un jour est défini, l'application vous alerte à l'approche ou en cas de retard de l'échéance.",
  "إذن SMS غير ممنوح": "Permission SMS non accordée",
  "إرسال رسالة تجريبية": "Envoyer un SMS de test",
  "إستعادة": "Restaurer",
  "إضافة زبون جديد": "Ajouter un nouveau client",
  "إضافة فئات جديدة": "Ajouter des catégories",
  "إضافة فئة زبائن جديدة": "Ajouter une catégorie de clients",
  "إعداد الجدولة والقوالب والسجل — الإرسال من هاتف المالك فقط": "Planification, modèles et historique — envoi depuis le téléphone du propriétaire uniquement",
  "إعدادات SMS": "Paramètres SMS",
  "إعدادات الرسائل النصية": "Paramètres des SMS",
  "إعدادات رسائل SMS": "Paramètres des SMS",
  "إظهار رمز QR لاقتران هاتف العامل": "Afficher le QR pour associer le téléphone de l'employé",
  "إغلاق": "Fermer",
  "إقران هاتف جديد": "Associer un nouveau téléphone",
  "إلغاء": "Annuler",
  "إلغاء الاقتران": "Dissocier",
  "ابحث بالاسم أو الهاتف": "Rechercher par nom ou téléphone",
  "ابحث بالاسم أو الهاتف...": "Rechercher par nom ou téléphone...",
  "ابدأ بإدخال المبلغ": "Saisissez un montant",
  "اختبار الإرسال": "Tester l'envoi",
  "اختر الفئة التي تريد نقل الزبون إليها لتمكينه من أخذ الدين مجددًا:": "Choisissez la catégorie vers laquelle transférer le client pour qu'il puisse reprendre une dette :",
  "اختياري": "optionnel",
  "ادخل كود التفعيل من عند الموزع": "Saisissez le code d'activation fourni par le distributeur",
  "استرجاع الحسابات أو البيانات المحذوفة خطأً": "Restaurer les comptes ou données supprimés par erreur",
  "استرجاع كلمة المرور": "Récupérer le mot de passe",
  "اسم الزبون": "Nom du client",
  "اسم الزبون *": "Nom du client *",
  "اسم الفئة الجديدة": "Nom de la nouvelle catégorie",
  "اسم المحل أو التاجر الذي يظهر للزبون": "Nom du magasin ou du commerçant affiché au client",
  "اسم المحل في الرسالة": "Nom du magasin dans le SMS",
  "اضغط على أي زبون للانتقال مباشرة إلى ملفه وكشف حسابه:": "Touchez un client pour ouvrir directement sa fiche et son relevé :",
  "اضغط على عملية لاستعمال نتيجتها": "Touchez une opération pour utiliser son résultat",
  "اضغط لنسخ الكود": "Touchez pour copier le code",
  "اقتران": "Associer",
  "اكتب اسم أو لقب الزبون": "Nom ou surnom du client",
  "اكتب اسم الفئة": "Saisissez le nom de la catégorie",
  "الأجهزة المصرح بها للمتجر:": "Appareils autorisés pour le magasin :",
  "الأجهزة المصرح بها ورخصة المتجر": "Appareils autorisés et licence du magasin",
  "الأيام الافتراضية: 1 و4 و8 و15، ويمكن تغييرها.": "Jours par défaut : 1, 4, 8 et 15 (modifiables).",
  "الأيقونة أو الرمز": "Icône ou symbole",
  "الإحصائيات": "Statistiques",
  "الإحصائيات وخزينة الديون": "Statistiques et trésorerie des dettes",
  "الإرسال متاح داخل تطبيق أندرويد فقط": "L'envoi est disponible uniquement dans l'application Android",
  "الإعدادات": "Paramètres",
  "الافتراضي 09:00–22:00. تُرتّب الرسائل حسب أقدم دين متأخر وتُرسل بالتتابع لتجنب الإرسال الجماعي.": "Par défaut 09:00–22:00. Les SMS sont triés par dette en retard la plus ancienne et envoyés séquentiellement.",
  "الاقتران يتم من هاتف العامل فقط": "L'association se fait uniquement depuis le téléphone de l'employé",
  "الباقي": "Reste",
  "التاريخ: {}": "Date : {}",
  "التخزين الآمن غير متاح": "Stockage sécurisé indisponible",
  "التذاكر المعلقة (دين غير مرحل)": "Tickets en attente (dette non transférée)",
  "التصنيف": "Catégorie",
  "التنبيهات": "Alertes",
  "التنبيهات والإشعارات الذكية": "Alertes et notifications intelligentes",
  "التنبيهات والمواعيد": "Alertes et échéances",
  "التنقل": "Navigation",
  "الحذف التام": "Suppression définitive",
  "الحساب بالسنتيم بالعامية": "Affichage des montants en centimes",
  "الحمد لله، لا يوجد أي زبون متأخر عن موعد السداد ✅": "Aucun client en retard sur son échéance, Dieu merci ✅",
  "الدين الحالي": "Dette actuelle",
  "الدين القديم:": "Ancienne dette :",
  "الدين المحدد غير موجود أو تمت تسويته": "La dette sélectionnée est introuvable ou déjà soldée",
  "الدين المراد تمديده": "Dette à prolonger",
  "الديون المضمونة": "Dettes garanties",
  "الراتب بعد": "Paie dans",
  "الرمز صالح 5 دقائق ولاستخدام واحد": "Code valable 5 minutes et à usage unique",
  "الزبائن المتأخرون عن موعد السداد": "Clients en retard sur leur échéance",
  "الزبائن المديونون": "Clients débiteurs",
  "الزبائن المنضبطون في وقتهم": "Clients qui paient à temps",
  "الزبون «{}» في القائمة السوداء حالياً. هل تريد رفع الحظر عنه وترحيل تذكرة #{} ({} دج) لحسابه؟": "Le client « {} » est actuellement sur liste noire. Lever le blocage et transférer le ticket #{} ({} DA) à son compte ?",
  "الزبون: {}": "Client : {}",
  "الساعة {}": "Heure {}",
  "السقف": "Plafond",
  "السقف المسموح: {} دج": "Plafond autorisé : {} DA",
  "السلام عليكم، أريد تفعيل رخصة تطبيق DEYN لمعرف جهازي.": "Bonjour, je souhaite activer la licence de l'application DEYN pour l'identifiant de mon appareil.",
  "السماح بإرسال تذكيرات SMS لهذا الزبون": "Autoriser l'envoi de rappels SMS à ce client",
  "السماح له بأخذ دين جديد ونقله للزبائن النشطين": "L'autoriser à reprendre une dette et le transférer aux clients actifs",
  "السيد": "Monsieur",
  "السيد / Monsieur": "Monsieur",
  "السيدة": "Madame",
  "السيدة / Madame": "Madame",
  "الصفحة 1 من 1": "Page 1 sur 1",
  "الصق الكود يدوياً بالضغط المطوّل داخل الخانة": "Collez le code manuellement par appui long dans le champ",
  "العامل هو من يبدأ الاتصال": "C'est l'employé qui lance la connexion",
  "العربية": "Arabe",
  "العربية • Français": "Français • Arabe",
  "العناصر المحفوظة مؤقتاً:": "Éléments conservés temporairement :",
  "الفاصل بين الرسائل (بالدقائق)": "Intervalle entre les SMS (en minutes)",
  "القائمة السوداء": "Liste noire",
  "القالب العربي": "Modèle arabe",
  "القالب الفرنسي": "Modèle français",
  "القالب طويل جدًا — الحد الأقصى 500 حرف لكل لغة": "Le modèle est trop long — maximum 500 caractères par langue",
  "الكل": "Tous",
  "اللغة / Langue": "Langue",
  "اللقب": "Civilité",
  "المبلغ (دج)": "Montant (DA)",
  "المبلغ المديون به (من الكراس القديم إن وجد)": "Montant dû (de l'ancien carnet, le cas échéant)",
  "المبلغ المسجّل": "Montant enregistré",
  "المبلغ المسدد (دج)": "Montant payé (DA)",
  "المبلغ المسدد أكبر من مجموع الدين الحالي والسلعة الجديدة": "Le montant payé dépasse le total de la dette actuelle et du nouvel article",
  "المبلغ المسدد أكبر من مجموع الدين والسلعة": "Le montant payé dépasse le total de la dette et de l'article",
  "المتأخرون ({})": "En retard ({})",
  "المتغيرات: {title} اللقب، {name} الاسم، {amount} المبلغ، {date} تاريخ الاستحقاق، {store} اسم المحل إن كان موجودًا في ملف المتجر. الإعداد الحالي لا يحتوي على اسم متجر، لذلك لن يُضاف اسم غير موجود. الرسائل الطويلة قد تُحسب عدة وحدات SMS حسب شركة الاتصالات.": "Variables : {title} civilité, {name} nom, {amount} montant, {date} date d'échéance, {store} nom du magasin. Les messages longs peuvent compter pour plusieurs unités SMS selon l'opérateur.",
  "المدة": "Durée",
  "المزامنة بين الهاتفين": "Synchronisation entre les deux téléphones",
  "المزامنة تتم تلقائيًا عند اتصال هاتف العامل": "La synchronisation se fait automatiquement lorsque le téléphone de l'employé se connecte",
  "المزامنة غير متاحة على هذا الجهاز": "La synchronisation n'est pas disponible sur cet appareil",
  "المزامنة غير متاحة في هذا الإصدار/الجهاز.": "La synchronisation n'est pas disponible dans cette version/sur cet appareil.",
  "المنضبطون ({})": "Ponctuels ({})",
  "النوع:": "Type :",
  "الهاتف": "Téléphone",
  "الوحدة": "Unité",
  "الوسم: {}": "Étiquette : {}",
  "اليوم {}": "Jour {}",
  "اليوم موعد السداد المحدد ({} في الشهر)": "Aujourd'hui est le jour de paiement prévu (le {} du mois)",
  "انتهت صلاحية الرمز": "Le code a expiré",
  "انتهت صلاحية كود الاسترداد": "Le code de récupération a expiré",
  "انتهت مدة الترخيص — أدخل كود تفعيل جديد": "La licence a expiré — saisissez un nouveau code d'activation",
  "انقر لتعديل الملاحظة": "Touchez pour modifier la note",
  "بداية الإرسال (ثابتة)": "Début d'envoi (fixe)",
  "بداية الإرسال ثابتة 09:00": "Début d'envoi fixe à 09:00",
  "بدون رقم": "Sans numéro",
  "بدون سقف أقصى": "Sans plafond maximal",
  "بدون لقب": "Sans titre",
  "بدون وسم": "Sans étiquette",
  "بطالة / عمال يوميون": "Sans emploi / journaliers",
  "بيانات هذا الهاتف تجريبية": "Les données de ce téléphone sont des données de démonstration",
  "تأكيد": "Confirmer",
  "تأكيد الدين": "Confirmer la dette",
  "تأكيد العملية": "Confirmer l'opération",
  "تأكيد رغم تجاوز السقف": "Confirmer malgré le dépassement du plafond",
  "تأكيد كلمة المرور *": "Confirmer le mot de passe *",
  "تأكيد كلمة المرور غير مطابق": "La confirmation du mot de passe ne correspond pas",
  "تاريخ النسخة:": "Date de la copie :",
  "تتم عبر شبكة Wi-Fi المحلية فقط ومشفّرة من طرف إلى طرف، دون خادم سحابي. يعمل التطبيق دون إنترنت دائمًا، وتُرسل التغييرات عند توفر الاتصال.": "Elle se fait uniquement via le Wi-Fi local, chiffrée de bout en bout, sans serveur cloud. L'application fonctionne toujours sans internet et les modifications sont envoyées dès que la connexion est disponible.",
  "تحذير: ديون حرجة تحتاج تدخلاً": "Attention : dettes critiques nécessitant une intervention",
  "تحقق من الأيام والساعات والفاصل الزمني": "Vérifiez les jours, les heures et l'intervalle",
  "تحقق من مدة التمديد": "Vérifiez la durée de prolongation",
  "تحقق وتعيين كلمة مرور جديدة": "Vérifier et définir un nouveau mot de passe",
  "تذكرة": "Ticket",
  "تذكرة #{}": "Ticket #{}",
  "تذكرة #{} —": "Ticket #{} —",
  "تذكرة معلقة #{} ({} دج)": "Ticket en attente #{} ({} DA)",
  "تذكيرات SMS للزبائن": "Rappels SMS aux clients",
  "تراجع": "Annuler",
  "ترتيب جميع المديونين تنازلياً": "Classement de tous les débiteurs par ordre décroissant",
  "ترحيل للزبون": "Transférer au client",
  "ترسل الرسائل من شريحة هاتف المالك فقط. يجب توفر رصيد SMS وشبكة الهاتف. قبول أندرويد للرسالة لا يعني تأكيد وصولها إلى هاتف الزبون.": "Les SMS sont envoyés uniquement depuis la carte SIM du propriétaire. Un crédit SMS et le réseau mobile sont requis. L'acceptation par Android ne garantit pas la réception par le client.",
  "تسجيل دين جديد": "Enregistrer une nouvelle dette",
  "تسجيل ديون وتسديد فقط • الحذف مقفل 🔒": "Enregistrement de dettes et paiements uniquement • suppression verrouillée 🔒",
  "تسديد": "Paiement",
  "تسديد دفعة مع سلعة جديدة": "Paiement avec un nouvel article",
  "تسديد دين": "Payer une dette",
  "تسيير الديون بكل سهولة": "Gérez vos dettes en toute simplicité",
  "تصفير شامل": "Remise à zéro totale",
  "تصنيف الزبون *": "Catégorie du client *",
  "تطبيق DEYN مقفل": "Application DEYN verrouillée",
  "تطبيق DEYN — تسيير الديون بكل سهولة وبدون إنترنت": "Application DEYN — gérez vos dettes simplement et sans internet",
  "تطبيق آمن ويشتغل بدون انترنت": "Application sécurisée qui fonctionne sans internet",
  "تعديل إعدادات الرسائل": "Modifier les paramètres SMS",
  "تعديل البيانات": "Modifier les données",
  "تعديل بيانات الزبائن": "Modifier les données des clients",
  "تعديل بيانات الزبون": "Modifier les données du client",
  "تعديل ملاحظة التذكرة": "Modifier la note du ticket",
  "تعذر إرسال الاختبار:": "Échec de l'envoi du test :",
  "تعذر إرسال الاختبار: {}": "Échec de l'envoi du test : {}",
  "تعذّر إتمام التفعيل الآمن": "Impossible de terminer l'activation sécurisée",
  "تعذّر إنشاء ملف الإنقاذ. لا تمسح بيانات التطبيق.": "Impossible de créer le fichier de secours. N'effacez pas les données de l'application.",
  "تعذّر الاقتران — تأكد من الشبكة ومن أن الرمز لم ينتهِ": "Association impossible — vérifiez le réseau et que le code n'a pas expiré",
  "تعذّر التحقق من حفظ بيانات الترخيص": "Impossible de vérifier l'enregistrement de la licence",
  "تعذّر النسخ": "Copie impossible",
  "تعذّر النسخ — اضغط مطولاً على المعرّف": "Copie impossible — appuyez longuement sur l'identifiant",
  "تعذّر النسخ — اضغط مطولاً على المعرّف لنسخه": "Copie impossible — appuyez longuement sur l'identifiant pour le copier",
  "تعذّر تحميل النسخة": "Impossible de charger la copie",
  "تعذّر تشغيل الحماية الآمنة:": "Impossible de démarrer la protection sécurisée :",
  "تعذّر تشغيل الحماية الآمنة: {}": "Impossible de démarrer la protection sécurisée : {}",
  "تعذّر حفظ آخر تغيير. أوقفنا الاستخدام حتى لا تواصل إدخال بيانات قد لا تُحفظ.": "Impossible d'enregistrer la dernière modification. Nous avons arrêté l'utilisation pour éviter de saisir des données qui pourraient ne pas être sauvegardées.",
  "تعذّر حفظ سجل الاسترداد — لم يُستعمل الكود": "Impossible d'enregistrer le registre de récupération — le code n'a pas été utilisé",
  "تعذّر حفظ كلمة المرور بأمان": "Impossible d'enregistrer le mot de passe en toute sécurité",
  "تعذّر قراءة بيانات DEYN بشكل سليم. لم نستبدلها بالبيانات التجريبية ولم نحذفها.": "Impossible de lire correctement les données DEYN. Nous ne les avons ni remplacées par des données de démonstration ni supprimées.",
  "تعذّر مسح الرمز:": "Échec du scan :",
  "تعذّر مسح الرمز: {}": "Échec du scan : {}",
  "تعذّرت المزامنة": "Échec de la synchronisation",
  "تعذّرت المزامنة:": "Échec de la synchronisation :",
  "تعذّرت المزامنة: {}": "Échec de la synchronisation : {}",
  "تعذّرت المزامنة: {} — ستُعاد المحاولة تلقائيًا": "Échec de la synchronisation : {} — nouvelle tentative automatique",
  "تعذّرت قراءة سجل الاسترداد بأمان": "Impossible de lire le registre de récupération en toute sécurité",
  "تعذّرت قراءة سجل التفعيل بأمان": "Impossible de lire le registre d'activation en toute sécurité",
  "تعيين كلمة المرور أو تغييرها (الاسترجاع بكود موقّع من الدعم)": "Définir ou changer le mot de passe (récupération par code signé du support)",
  "تعيين كلمة مرور المالك": "Définir le mot de passe du propriétaire",
  "تغيير كلمة المرور": "Changer le mot de passe",
  "تفاصيل السلعة أو الملاحظة": "Détails de l'article ou note",
  "تفريغ السلة نهائياً": "Vider la corbeille définitivement",
  "تفريغ سلة المهملات": "Vider la corbeille",
  "تفريغ نهائي": "Vider définitivement",
  "تفعيل": "Activer",
  "تفعيل DEYN": "Activer DEYN",
  "تفعيل الرسائل النصية": "Activer les rappels SMS",
  "تفعيل وضع المالك": "Activer le mode propriétaire",
  "تلقائي (عربي)": "Automatique (Arabe)",
  "تم إرسال رسالة الاختبار إلى الشبكة بنجاح": "SMS de test envoyé au réseau mobile avec succès",
  "تم إرسال رسالة الاختبار وتأكيد تسليمها إلى الهاتف": "SMS de test envoyé et livraison confirmée sur le téléphone",
  "تم إيقاف SMS لأن إذن الرسائل غير متاح": "SMS désactivés car la permission d'envoi n'est pas accordée",
  "تم إيقاف التفعيل بسبب تغيير غير طبيعي في ساعة الجهاز": "Activation suspendue à cause d'un changement anormal de l'horloge de l'appareil",
  "تم إيقاف جميع رسائل SMS مؤقتًا": "Tous les rappels SMS ont été temporairement désactivés",
  "تم استخدام الرمز ✅": "Code utilisé ✅",
  "تم استرجاع آخر نسخة سليمة من بياناتك بعد اكتشاف تلف في النسخة الأحدث ⚠️": "La dernière copie saine de vos données a été restaurée après détection d'un dommage dans la plus récente ⚠️",
  "تم الاقتران والمزامنة بنجاح ✅": "Association et synchronisation réussies ✅",
  "تم التحقق من كود الاسترداد ✅ عيّن كلمة مرور جديدة": "Code de récupération vérifié ✅ Définissez un nouveau mot de passe",
  "تم الترحيل إلى {} — تجاوز السقف": "Transféré à {} — plafond dépassé",
  "تم التسديد ورُفع الحظر عن {} وأصبح بإمكانه أخذ الدين بنجاح ✅": "Paiement effectué et blocage levé pour {} : il peut de nouveau prendre une dette ✅",
  "تم الحذف التام نهائياً": "Suppression définitive effectuée",
  "تم الحفظ — تذكرة #{} ({} دج)": "Enregistré — ticket #{} ({} DA)",
  "تم ترحيل {} دج إلى {}": "{} DA transférés à {}",
  "تم تسديد {} دج وإضافة سلعة بـ {} دج — الباقي {} دج": "{} DA payés et article de {} DA ajouté — reste {} DA",
  "تم تسديد {} دج — الباقي {} دج": "{} DA payés — reste {} DA",
  "تم تعيين كلمة المرور الجديدة بنجاح 🔒": "Nouveau mot de passe défini avec succès 🔒",
  "تم تفريغ سلة المهملات نهائياً": "Corbeille vidée définitivement",
  "تم تفعيل SMS للزبائن الذين لديهم أرقام هاتف": "SMS activés pour les clients disposant d'un numéro de téléphone",
  "تم تفعيل وضع العامل (تسجيل وتسديد فقط • الحذف مقفل 🔒)": "Mode employé activé (enregistrement et paiement uniquement • suppression verrouillée 🔒)",
  "تم تفعيل وضع المالك بنجاح (صلاحيات كاملة) 👑": "Mode propriétaire activé (droits complets) 👑",
  "تم حذف البيانات ونقلها لسلة المهملات (يمكنك استرجاعها) ✅": "Données supprimées et déplacées vers la corbeille (vous pouvez les restaurer) ✅",
  "تم حذف فئة «{}» بنجاح": "Catégorie « {} » supprimée avec succès",
  "تم حفظ إعدادات SMS بنجاح": "Paramètres SMS enregistrés avec succès",
  "تم حفظ التعديلات": "Modifications enregistrées",
  "تم حفظ ملاحظة التذكرة": "Note du ticket enregistrée",
  "تم رصد إرجاع وقت الهاتف. يرجى ضبط الساعة الحقيقية لمتابعة العمل.": "Un retour en arrière de l'horloge du téléphone a été détecté. Réglez l'heure réelle pour continuer.",
  "تم رفع الحظر عن {} وترحيل {} دج لحسابه بنجاح ✅": "Blocage levé pour {} et {} DA transférés à son compte ✅",
  "تم رفع الحظر عن {} ونقله إلى «{}» بنجاح ✅": "Blocage levé pour {} et client transféré vers « {} » ✅",
  "تم مسح البيانات": "Données effacées",
  "تم مسح الذاكرة": "Mémoire effacée",
  "تم نسخ {} بنجاح 📋": "{} copié avec succès 📋",
  "تم نسخ كشف الحساب": "Relevé de compte copié",
  "تم نسخ معرّف الجهاز بنجاح": "Identifiant de l'appareil copié avec succès",
  "تم نسخ معرّف الجهاز 📋": "Identifiant de l'appareil copié 📋",
  "تم نقل التذكرة إلى سلة المهملات": "Ticket déplacé vers la corbeille",
  "تم نقل الزبون إلى سلة المهملات (يمكنك استرجاعه)": "Client déplacé vers la corbeille (vous pouvez le restaurer)",
  "تمت إستعادة التذكرة بنجاح ✅": "Ticket restauré avec succès ✅",
  "تمت إستعادة الزبون «{}» بنجاح ✅": "Client « {} » restauré avec succès ✅",
  "تمت إستعادة جميع البيانات بنجاح ✅": "Toutes les données ont été restaurées ✅",
  "تمت إضافة {} بنجاح": "{} ajouté avec succès",
  "تمت إضافة {} دج على {}": "{} DA ajoutés à {}",
  "تمت إضافة {} مع رصيد سابق {} دج": "{} ajouté avec un solde antérieur de {} DA",
  "تمت إضافة سلعة بـ {} دج — الدين الحالي {} دج": "Article de {} DA ajouté — dette actuelle {} DA",
  "تمت إضافة فئة «{}»": "Catégorie « {} » ajoutée",
  "تمت الإضافة — الزبون تجاوز السقف": "Ajouté — le client a dépassé le plafond",
  "تمت المزامنة بنجاح ✅": "Synchronisation réussie ✅",
  "تمت المزامنة ✅": "Synchronisation terminée ✅",
  "تمت المزامنة ✅ (أُرسل": "Synchronisation terminée ✅ (envoyés",
  "تمت المزامنة ✅ (أُرسل {} • استُلم {})": "Synchronisation terminée ✅ (envoyés {} • reçus {})",
  "تمديد موعد دين بعد هذه الدفعة (اختياري)": "Prolonger l'échéance d'une dette après ce paiement (optionnel)",
  "تموين": "Courses",
  "تموين الشهر": "Courses du mois",
  "تموين كبير": "Grosses courses",
  "تنبيه تلقائي بمواعيد السداد وتجاوز السقف": "Alerte automatique sur les échéances et les dépassements de plafond",
  "تنبيه نشط": "Alerte active",
  "تنبيه: تشفير البيانات غير متاح على هذا الجهاز، تعمل بياناتك دون تشفير ⚠️": "Attention : le chiffrement des données n'est pas disponible sur cet appareil, vos données ne sont pas chiffrées ⚠️",
  "توجد {} زبائن مسجلين في فئة «{}». سيتم نقلهم تلقائياً إلى الفئة المتبقية.": "{} client(s) sont enregistrés dans la catégorie « {} ». Ils seront transférés automatiquement vers la catégorie restante.",
  "توزيع الديون على فئات المتجر": "Répartition des dettes par catégorie du magasin",
  "توزيع الفئات ({})": "Répartition par catégorie ({})",
  "توقّف مؤقت لحماية بياناتك": "Arrêt temporaire pour protéger vos données",
  "ثانية": "seconde",
  "جاري": "Compte courant",
  "جارٍ الاقتران…": "Association en cours…",
  "جدول التذكير بعد الاستحقاق": "Calendrier des rappels après l'échéance",
  "جرّب اسمًا آخر أو أضف زبونًا جديدًا.": "Essayez un autre nom ou ajoutez un nouveau client.",
  "جميع الزبائن ملتزمون بمواعيد السداد وسقوف الديون المحددة.": "Tous les clients respectent les échéances et les plafonds de dette fixés.",
  "جهازان فقط 🔒": "2 appareils maximum 🔒",
  "حالة الإرسال غير مؤكدة — لم نعد المحاولة لتجنب التكرار": "État d'envoi incertain — non renvoyé pour éviter les doublons",
  "حذف": "Supprimer",
  "حذف البيانات": "Supprimer les données",
  "حذف التذاكر": "Supprimer les tickets",
  "حذف التذكرة": "Supprimer le ticket",
  "حذف الزبائن": "Supprimer les clients",
  "حذف الزبون": "Supprimer le client",
  "حذف الفئات": "Supprimer les catégories",
  "حذف الفئة": "Supprimer la catégorie",
  "حذف تام": "Suppression définitive",
  "حذف تام نهائياً": "Suppression définitive",
  "حذف فئة «{}»": "Supprimer la catégorie « {} »",
  "حذف وتصفير البيانات": "Supprimer et remettre à zéro les données",
  "حساب بدون ديون": "Compte sans dettes",
  "حساب سريع": "Calcul rapide",
  "حساب محظور (القائمة السوداء)": "Compte bloqué (liste noire)",
  "حساب محظور — لا يمكن إضافة دين جديد": "Compte bloqué — impossible d'ajouter une nouvelle dette",
  "حفظ": "Enregistrer",
  "حفظ الإعدادات": "Enregistrer les paramètres",
  "حفظ التعديلات": "Enregistrer les modifications",
  "حفظ الزبون": "Enregistrer le client",
  "حفظ الفئات": "Enregistrer les catégories",
  "حفظ الفئة": "Enregistrer la catégorie",
  "حفظ الملاحظة": "Enregistrer la note",
  "حفظ كلمة المرور": "Enregistrer le mot de passe",
  "حفظ ملف JSON": "Enregistrer en JSON",
  "حفظ ملف PDF": "Enregistrer en PDF",
  "حفظ نسخة إنقاذ من البيانات الموجودة": "Enregistrer une copie de secours des données existantes",
  "حليب وخبز": "Lait et pain",
  "حمزة بلقاسم": "Hamza Belkacem",
  "خبز وحليب": "Pain et lait",
  "خديجة لعروسي": "Khadidja Laroussi",
  "خزينة الديون الكلية في السوق": "Trésorerie totale des dettes sur le marché",
  "خضر وفواكه": "Fruits et légumes",
  "خطأ غير معروف": "Erreur inconnue",
  "دج": "DA",
  "دج{}": "DA{}",
  "دعم فني وتفعيل": "Assistance et activation",
  "دفتر الزبائن": "Carnet des clients",
  "دفتر حسابات مفرغ بالكامل": "Carnet de comptes entièrement vidé",
  "دقيقة": "minute",
  "دين": "Dette",
  "دين سابق من الكراس القديم": "Dette antérieure de l'ancien carnet",
  "دين سريع": "Dette rapide",
  "دين متبقي: {} دج ({})": "Dette restante : {} DA ({})",
  "دين معلق": "Dette en attente",
  "ديون متأخرة عن موعدها": "Dettes en retard sur leur échéance",
  "ديون مضمونة": "Dettes garanties",
  "ديون معلقة": "Dettes en attente",
  "ربط هاتف المالك بهاتف العامل عبر Wi-Fi المحلي دون إنترنت": "Reliez le téléphone du propriétaire à celui de l'employé via le Wi-Fi local, sans internet",
  "رسالة الاختبار تجاوزت حد الرسالة الواحدة": "Le SMS de test dépasse la limite d'un segment",
  "رسالة الاختبار سبق إرسالها": "Ce SMS de test a déjà été envoyé",
  "رسالة تجريبية": "SMS de test",
  "رشيد قرين": "Rachid Guerine",
  "رفع الحظر عن الزبون": "Lever le blocage du client",
  "رفع الحظر عن الزبون بعد التسديد": "Lever le blocage du client après paiement",
  "رفع الحظر والترحيل": "Lever le blocage et transférer",
  "رفع الحظر وترحيل التذكرة": "Lever le blocage et transférer le ticket",
  "رفع الحظر وتغيير الفئات": "Lever le blocage et changer de catégorie",
  "رقم الهاتف (اختياري)": "Numéro de téléphone (optionnel)",
  "رقم الهاتف الذي تريد إرسال الاختبار إليه": "Numéro de téléphone pour l'envoi du test",
  "رمز الاقتران (امسح QR من هاتف المالك أو الصقه هنا)": "Code d'association (scannez le QR du propriétaire ou collez-le ici)",
  "رمز الاقتران غير صالح": "Code d'association invalide",
  "زبائن هذه الفئة يسددون في موعدهم تلقائياً": "Les clients de cette catégorie paient automatiquement à l'échéance",
  "زبون": "client",
  "زيادة دين": "Augmenter la dette",
  "زيت وسميد": "Huile et semoule",
  "ساعة": "heures",
  "ساعة. صحّح ساعة الجهاز أو اتصل بالإنترنت.": "heure(s). Corrigez l'horloge de l'appareil ou connectez-vous à internet.",
  "سجائر ومشروبات": "Cigarettes et boissons",
  "سجل التفعيل غير صالح": "Le registre d'activation est invalide",
  "سجل الرسائل": "Historique des SMS",
  "سجل العمليات": "Historique des opérations",
  "سجل رسائل SMS": "Historique des SMS",
  "سجّل مبلغًا من «دين سريع» ثم اضغط حفظ، وسيظهر هنا حتى ترحّله إلى زبون.": "Saisissez un montant dans « Dette rapide » puis touchez Enregistrer ; il restera ici jusqu'à son transfert à un client.",
  "سدّد كامل": "Tout payer",
  "سفيان مرابط": "Sofiane Merabet",
  "سقف الدين الأقصى (اختياري)": "Plafond de dette maximal (optionnel)",
  "سقف الدين التلقائي لهذه الفئة (دج)": "Plafond de dette automatique de cette catégorie (DA)",
  "سقف تلقائي: {} دج": "Plafond automatique : {} DA",
  "سلة المهملات": "Corbeille",
  "سلة المهملات فارغة": "La corbeille est vide",
  "سلعة جديدة: {}": "Nouvel article : {}",
  "سلعة مأخوذة مع التسديد": "Article pris avec le paiement",
  "سيتم استبدال البيانات التجريبية ببيانات هاتف المالك. هل تريد المتابعة؟": "Les données de démonstration seront remplacées par celles du téléphone du propriétaire. Continuer ?",
  "سيتم حذف جميع العناصر الموجودة في سلة المهملات نهائياً وبلا رجعة. هل أنت متأكد؟": "Tous les éléments de la corbeille seront supprimés définitivement et sans retour. Êtes-vous sûr ?",
  "سيتم حذف كل الزبائن والتذاكر والسجلات. لا يمكن التراجع.": "Tous les clients, tickets et enregistrements seront supprimés. Action irréversible.",
  "سيتم مسح هذا العنصر نهائياً ولن يمكنك استرجاعه أبداً. هل تريد المتابعة؟": "Cet élément sera effacé définitivement et ne pourra jamais être restauré. Continuer ?",
  "سيتم نقل تذكرة #{} ({} دج) إلى سلة المهملات.": "Le ticket #{} ({} DA) sera déplacé vers la corbeille.",
  "سير ديونك بطريقة سهلة وذكية": "Gérez vos dettes de façon simple et intelligente",
  "سيولة آمنة ومستقرة جداً": "Trésorerie sûre et très stable",
  "سيولة مقبولة • يلزم متابعة المتأخرين": "Trésorerie correcte • suivre les retardataires",
  "سيُنقل حساب {} إلى سلة المهملات.": "Le compte de {} sera déplacé vers la corbeille.",
  "شكرًا على ثقتكم 🤝": "Merci de votre confiance 🤝",
  "شهارة": "Salariés (paie mensuelle)",
  "صافي الدين المتبقي الجديد:": "Nouvelle dette nette restante :",
  "صلاحيات كاملة • صالح لغاية: {}": "Droits complets • valable jusqu'au : {}",
  "طلب كلمة المرور عند فتح التطبيق لحماية الخصوصية": "Demander le mot de passe à l'ouverture pour protéger la confidentialité",
  "ع": "AR",
  "عبد الحق شريف": "Abdelhak Chérif",
  "عدد الزبائن المديونين": "Nombre de clients débiteurs",
  "عذراً، {} خاصة بصاحب المحل فقط 🔒": "Désolé, « {} » est réservé au propriétaire 🔒",
  "عذراً، تعديل بيانات الزبائن متاح لصاحب المحل فقط 🔒": "Désolé, la modification des clients est réservée au propriétaire 🔒",
  "عذراً، قفل التطبيق خاص بصاحب المحل فقط 🔒": "Désolé, le verrouillage de l'application est réservé au propriétaire 🔒",
  "عرض / تعديل القالب العربي": "Afficher / modifier le modèle arabe",
  "على هاتفك أو طباعتها مباشرة على الورق.": "sur votre téléphone ou l'imprimer directement sur papier.",
  "عمي مراد": "Ammi Mourad",
  "عند التفعيل، يتم تمكين كل الزبائن الذين لديهم رقم هاتف. يمكنك تعطيل أي زبون بشكل فردي.": "À l'activation, tous les clients ayant un numéro de téléphone sont activés. Vous pouvez désactiver chaque client individuellement.",
  "عنوان المالك غير معروف: أعد الاقتران بمسح رمز QR": "Adresse du propriétaire inconnue : réassociez en scannant le QR",
  "عيّن كلمة مرور المالك أولاً ثم فعّل القفل": "Définissez d'abord le mot de passe du propriétaire puis activez le verrouillage",
  "غير محدد": "Non défini",
  "فارغة": "vide",
  "فتح التطبيق 🔓": "Ouvrir l'application 🔓",
  "فترة الإرسال والتوزيع": "Plage horaire et cadence d'envoi",
  "فشل إرسال رسالة الاختبار إلى الشبكة": "Échec de l'envoi du SMS de test au réseau",
  "فشل جزئي في إرسال الاختبار ({}/{})": "Échec partiel de l'envoi du test ({}/{})",
  "قبل": "il y a",
  "قبل {} دقيقة": "il y a {} minute(s)",
  "قبل {} ساعة": "il y a {} heure(s)",
  "قبل {} يوم": "il y a {} jour(s)",
  "قبل أندرويد إرسال اختبار قصير (رسالة واحدة)": "Android a accepté l'envoi du SMS de test",
  "قبل أندرويد الإرسال": "Envoi accepté par Android",
  "قبل لحظات": "il y a un instant",
  "قَبِل أندرويد طلب الإرسال وبانتظار تأكيد الشبكة": "Demande acceptée par Android, en attente de confirmation réseau",
  "قطع نقدية": "Pièces de monnaie",
  "قفل التطبيق بكلمة المرور": "Verrouiller l'application par mot de passe",
  "قوالب الرسائل القابلة للتعديل": "Modèles de SMS personnalisables",
  "كامل الدين": "Toute la dette",
  "كبار الديون ({})": "Plus grosses dettes ({})",
  "كراس حسابات ورقي مقروء (PDF)": "Carnet de comptes papier lisible (PDF)",
  "كراس ديون المتجر — DEYN": "Carnet de dettes du magasin — DEYN",
  "كراس ديون المتجر — DEYN — {}": "Carnet de dettes du magasin — DEYN — {}",
  "كل من يحمل ديناً في المحل مرتبين من أعلى قيمة إلى الأقل:": "Tous ceux qui ont une dette au magasin, classés du montant le plus élevé au plus faible :",
  "كلمة المرور الجديدة * ({} أحرف أو أرقام على الأقل)": "Nouveau mot de passe * (au moins {} caractères)",
  "كلمة المرور الجديدة يجب أن تتكون من {} أحرف أو أرقام على الأقل": "Le nouveau mot de passe doit comporter au moins {} caractères",
  "كلمة المرور الحالية *": "Mot de passe actuel *",
  "كلمة المرور الرئيسية": "Mot de passe principal",
  "كلمة المرور تحمي وضع المالك وقفل التطبيق. لا توجد كلمة مرور افتراضية ولا يمكن لأحد تجاوزها.": "Le mot de passe protège le mode propriétaire et le verrouillage de l'application. Il n'existe aucun mot de passe par défaut et personne ne peut le contourner.",
  "كلمة المرور غير صحيحة ❌": "Mot de passe incorrect ❌",
  "كمال بوعزيز": "Kamel Bouaziz",
  "كود الاسترداد *": "Code de récupération *",
  "كود الاسترداد غير صالح": "Code de récupération invalide",
  "كود التفعيل": "Code d'activation",
  "كود التفعيل غير صالح لهذا الجهاز أو انتهت صلاحيته": "Code d'activation invalide pour cet appareil ou expiré",
  "كود الهاتف الرئيسي (صاحب المحل):": "Code du téléphone principal (propriétaire) :",
  "كود هاتف العامل": "Code du téléphone employé",
  "كود هاتف العامل:": "Code du téléphone employé :",
  "كود هاتف صاحب المحل (الرئيسي)": "Code du téléphone du propriétaire (principal)",
  "لأي استفسار، مساعدة أو تفعيل رخصة المتجر:": "Pour toute question, aide ou activation de la licence du magasin :",
  "لا تحذف التطبيق، ولا تمسح بياناته أو ذاكرته المؤقتة، ولا تضغط على إعادة التصفير.": "Ne désinstallez pas l'application, n'effacez ni ses données ni son cache, et ne touchez pas à la réinitialisation.",
  "لا توجد تنبيهات": "Aucune alerte",
  "لا توجد تنبيهات حالياً": "Aucune alerte pour le moment",
  "لا توجد ديون مسجلة حالياً": "Aucune dette enregistrée pour le moment",
  "لا توجد ديون مسجلة حالياً، الحمد لله.": "Aucune dette enregistrée pour le moment, Dieu merci.",
  "لا توجد ديون معلقة": "Aucune dette en attente",
  "لا توجد رسائل في السجل بعد": "Aucun SMS dans l'historique pour le moment",
  "لا توجد سجلات كافية حالياً": "Pas assez d'enregistrements pour le moment",
  "لا توجد عمليات بعد": "Aucune opération pour l'instant",
  "لا توجد فئات مطابقة": "Aucune catégorie correspondante",
  "لا توجد كلمة مرور للمالك بعد. استخدم كود الاسترداد لتعيين واحدة": "Aucun mot de passe propriétaire pour l'instant. Utilisez le code de récupération pour en définir un",
  "لا جذر لعدد سالب": "Pas de racine d'un nombre négatif",
  "لا شيء للتراجع": "Rien à annuler",
  "لا يمكن القسمة على صفر": "Division par zéro impossible",
  "لا يمكنه أخذ دين جديد حتى يُرفع الحظر": "Il ne peut pas prendre de nouvelle dette tant que le blocage n'est pas levé",
  "لا يوجد اتصال Wi-Fi محلي. اتصل بنفس شبكة الواي فاي ثم أعد المحاولة": "Pas de connexion Wi-Fi locale. Connectez-vous au même réseau Wi-Fi puis réessayez",
  "لا يوجد دين على هذا الزبون": "Ce client n'a aucune dette",
  "لا يوجد زبائن مسجلون في هذه الفئة": "Aucun client enregistré dans cette catégorie",
  "لا يوجد زبون بهذا الاسم": "Aucun client portant ce nom",
  "لا يوجد زبون مطابق": "Aucun client correspondant",
  "لا يوجد هاتف مالك مقترن": "Aucun téléphone propriétaire associé",
  "لا يوجد هاتف مقترن بعد.": "Aucun téléphone associé pour l'instant.",
  "لاحقاً": "Plus tard",
  "لحماية سجلات وديون متجرك من التطفل، يرجى إدخال كلمة المرور:": "Pour protéger les registres et dettes de votre magasin, saisissez le mot de passe :",
  "لصق": "Coller",
  "لصق كود التفعيل": "Coller le code d'activation",
  "لغة الرسالة": "Langue du SMS",
  "للتواصل معنا": "Nous contacter",
  "لم تنجح بعد": "Aucun succès pour l'instant",
  "لم يتم منح إذن إرسال الرسائل، بقيت الميزة متوقفة": "Permission SMS refusée, la fonctionnalité reste désactivée",
  "لن يتمكن هذا الهاتف من المزامنة بعد الآن. لن تُحذف أي بيانات من أي هاتف.": "Ce téléphone ne pourra plus se synchroniser. Aucune donnée ne sera supprimée d'aucun téléphone.",
  "ليجان (الشباب)": "Jeunes (Lidjan)",
  "مؤشر الأمان": "Indice de sécurité",
  "مؤشر الاستقرار وصحة التحصيل:": "Indice de stabilité et de santé du recouvrement :",
  "مبلغ التسديد أكبر من مجموع الدين والسلعة الجديدة": "Le montant payé dépasse le total de la dette et du nouvel article",
  "مبلغ الدين الحالي": "Montant de la dette actuelle",
  "متأخر عن موعد السداد بـ 2 يومين (كان يوم {})": "En retard sur l'échéance de 2 jours (c'était le {})",
  "متأخر عن موعد السداد بـ {} {} (كان يوم {})": "En retard sur l'échéance de {1} {2} (c'était le {3})",
  "متابعة": "Continuer",
  "مثال: 27 (اختياري)": "Exemple : 27 (optionnel)",
  "مثال: بنائين، عائلة، تجار جملة...": "Exemple : maçons, famille, grossistes...",
  "مثال: جاري": "Exemple : courant",
  "مثال: خبز وحليب": "Exemple : pain et lait",
  "مثال: دفعة من الحساب، أو تفاصيل السلعة المأخوذة...": "Exemple : acompte, ou détails de l'article pris...",
  "مثال: زيت وسكر، أو قهوة وحليب...": "Exemple : huile et sucre, ou café et lait...",
  "مثال: محل الأمانة": "Exemple : Magasin El Amana",
  "مجموع الديون في السوق": "Total des dettes sur le marché",
  "مجموع ما استرجعه المحل من الزبائن": "Total récupéré par le magasin auprès des clients",
  "محاولات كثيرة خاطئة. انتظر {} ثانية ⏳": "Trop de tentatives incorrectes. Patientez {} seconde(s) ⏳",
  "محظور": "Bloqué",
  "مدى الحياة": "À vie",
  "مراد زروقي": "Mourad Zerouki",
  "مراسلة عبر واتساب (الدعم الفني)": "Écrire sur WhatsApp (assistance technique)",
  "مرحباً بك مجدداً في DEYN 🔓": "Bon retour dans DEYN 🔓",
  "مزامنة الآن": "Synchroniser maintenant",
  "مسح الكل": "Tout effacer",
  "مسح كل البيانات": "Effacer toutes les données",
  "مشروبات": "Boissons",
  "معاينة كراس الديون الورقي:": "Aperçu du carnet de dettes papier :",
  "معرّف الجهاز": "Identifiant de l'appareil",
  "ملاحظة (اختياري)": "Note (optionnel)",
  "ملاحظة أو تفاصيل السلعة للتذكرة (تُحفظ في حساب الزبون):": "Note ou détails de l'article pour le ticket (enregistrés dans le compte du client) :",
  "ملف الإنقاذ قد يحتوي بيانات خاصة وكلمات مرور قديمة. احتفظ به في مكان آمن ولا ترسله قبل مراجعته.": "Le fichier de secours peut contenir des données privées et d'anciens mots de passe. Gardez-le en lieu sûr et ne l'envoyez pas avant de l'avoir vérifié.",
  "من 3: تم اكتشاف تغيير غير طبيعي في ساعة الجهاز. صحّح التاريخ والوقت.": "sur 3 : un changement anormal de l'horloge a été détecté. Corrigez la date et l'heure.",
  "مواد تنظيف وسكر": "Produits d'entretien et sucre",
  "مواد غذائية": "Produits alimentaires",
  "موعد استحقاق السلعة الجديدة (اختياري)": "Date d'échéance du nouvel article (optionnel)",
  "موعد استحقاق هذا الدين (اختياري)": "Date d'échéance de cette dette (optionnel)",
  "موعد السداد": "Date de paiement",
  "موعد السداد يوم {} من الشهر": "Échéance le {} de chaque mois",
  "موعده {}": "Échéance : {}",
  "ميزة SMS غير متاحة في هذه النسخة": "La fonction SMS n'est pas disponible dans cette version",
  "نادية بن عيسى": "Nadia Ben Aïssa",
  "نسخ": "Copier",
  "نسخ المعرّف": "Copier l'identifiant",
  "نسخ معرّف الجهاز": "Copier l'identifiant de l'appareil",
  "نسخ 📋": "Copier 📋",
  "نسخة ورقية منظمة لجميع الحسابات والديون": "Copie papier organisée de tous les comptes et dettes",
  "نسيت كلمة المرور؟": "Mot de passe oublié ?",
  "نسيت كلمة المرور؟ استخدم كود الاسترداد": "Mot de passe oublié ? Utilisez le code de récupération",
  "نقرة خفيفة عند كل ضغطة": "Léger clic à chaque appui",
  "نقل إلى المهملات": "Mettre à la corbeille",
  "نهاية الإرسال (حتى 22:00)": "Fin d'envoi (jusqu'à 22:00)",
  "هاتف العامل": "Téléphone de l'employé",
  "هاتف المالك": "Téléphone du propriétaire",
  "هاتف المالك الرئيسي + هاتف العامل المساعد": "Téléphone principal du propriétaire + téléphone de l'employé",
  "هذا الجهاز لا يدعم التحقق الآمن": "Cet appareil ne prend pas en charge la vérification sécurisée",
  "هذا الجهاز لا يدعم التحقق الآمن من Ed25519": "Cet appareil ne prend pas en charge la vérification sécurisée Ed25519",
  "هذا الجهاز مرخّص كجهاز عامل ولا يمكن تحويله إلى وضع المالك 🔒": "Cet appareil est licencié comme appareil employé et ne peut pas passer en mode propriétaire 🔒",
  "هذا الدين سيتم تسويته بالكامل بهذه الدفعة، اختر دينًا سيبقى منه رصيد": "Cette dette sera entièrement soldée par ce paiement ; choisissez une dette ayant un solde restant",
  "هذا الكود سبق استعماله": "Ce code a déjà été utilisé",
  "هذا الكود مخصص لجهاز آخر": "Ce code est destiné à un autre appareil",
  "هذه العملية": "Cette opération",
  "هل أنت متأكد من حذف جميع البيانات؟ ستُنقل كل الحسابات والتذاكر الحالية إلى سلة المهملات، ويمكنك استرجاعها بضغطة زر إن أردت.": "Voulez-vous vraiment supprimer toutes les données ? Tous les comptes et tickets actuels seront déplacés vers la corbeille et vous pourrez les restaurer en un clic.",
  "هل أنت متأكد من حذف فئة «{}»؟": "Voulez-vous vraiment supprimer la catégorie « {} » ?",
  "وسم": "Étiquette",
  "وضع القراءة فقط": "Mode lecture seule",
  "وضع القراءة فقط 🔒": "Mode lecture seule 🔒",
  "وضع القراءة فقط: لا يمكن إرسال SMS": "Mode lecture seule : impossible d'envoyer des SMS",
  "وضع القراءة فقط: لا يمكن الإضافة أو التعديل أو الحذف حاليًا 🔒": "Lecture seule : ajout, modification et suppression impossibles pour le moment 🔒",
  "وضع القراءة فقط: لا يمكن تغيير إعدادات SMS": "Mode lecture seule : impossible de modifier les paramètres SMS",
  "ونص": "et demi",
  "ياسين دحماني": "Yacine Dahmani",
  "يرجى كتابة اسم أو لقب الزبون": "Veuillez saisir le nom ou le surnom du client",
  "يعرض السجل قبول أندرويد أو حالة إرسال غير مؤكدة؛ ولا يثبت وصول الرسالة إلى هاتف الزبون.": "L'historique indique l'acceptation par Android ou un état incertain ; cela ne garantit pas la réception par le client.",
  "يقترب موعد السداد (بعد 2 يومين)": "L'échéance approche (dans 2 jours)",
  "يقترب موعد السداد (بعد {} {})": "L'échéance approche (dans {1} {2})",
  "يميز السجل بين قبول أندرويد، ونجاح إرسال كل الأجزاء للشبكة، وتأكيد التسليم، والفشل الجزئي أو الكلي.": "L'historique distingue l'acceptation par Android, l'envoi complet au réseau, la confirmation de livraison et l'échec partiel ou total.",
  "يمكنك حذف أي فئة لا تستعملها في محلك:": "Vous pouvez supprimer toute catégorie que vous n'utilisez pas dans votre magasin :",
  "يمكنك حفظ هذه النسخة كملف": "Vous pouvez enregistrer cette copie dans un fichier",
  "ينتهي بعد": "Expire dans",
  "ينتهي بعد {} ثانية": "Expire dans {} seconde(s)",
  "يُضاف هذا الاسم تلقائيًا مكان {store} في القالب العربي والفرنسي.": "Ce nom remplace automatiquement {store} dans les modèles arabe et français.",
  "يُمدد الدين الذي تختاره فقط، مع الاحتفاظ بتاريخ الموعد السابق وسجل التمديد.": "Seule la dette choisie est prolongée, tout en conservant l'ancienne échéance et l'historique.",
  "يوم": "jour",
  "يوم {} في الشهر": "Le {} de chaque mois",
  "يوم {} في الشهر (⚠️ متأخر {} يوم)": "Le {} de chaque mois (⚠️ en retard de {} jour(s))",
  "يوم الراتب اليوم": "Jour de paie aujourd'hui",
  "يوم السداد المتوقع في الشهر (اختياري)": "Jour de paiement prévu dans le mois (optionnel)",
  "يومين": "2 jours",
  "— الدين الحالي": "— Dette actuelle",
  "— ستُعاد المحاولة تلقائيًا": "— Nouvelle tentative automatique",
  "• {} {} {}{} دج{}": "• {} {} {}{} DA{}",
  "• استُلم": "• reçus",
  "⚙️ إدارة الفئات": "⚙️ Gérer les catégories",
  "⚠️ اقترب من السقف — بقي {} دج": "⚠️ Proche du plafond — il reste {} DA",
  "⚠️ الدين الجديد ({} دج) يتجاوز السقف ({} دج)": "⚠️ La nouvelle dette ({} DA) dépasse le plafond ({} DA)",
  "⚠️ انتهت مهلة تصحيح الساعة (لم يُفعَّل القفل بعد). صحّح تاريخ الجهاز.": "⚠️ Le délai de correction de l'horloge est écoulé (verrouillage pas encore activé). Corrigez la date de l'appareil.",
  "⚠️ تجاوز السقف بـ {} دج": "⚠️ Plafond dépassé de {} DA",
  "⚠️ تحذير": "⚠️ Avertissement",
  "⚠️ تحذير {} من 3: تم اكتشاف تغيير غير طبيعي في ساعة الجهاز. صحّح التاريخ والوقت.": "⚠️ Avertissement {} sur 3 : un changement anormal de l'horloge a été détecté. Corrigez la date et l'heure.",
  "⚠️ تعذّر حفظ حالة الوقت بأمان": "⚠️ Impossible d'enregistrer l'état de l'horloge en toute sécurité",
  "⚠️ تم تجاهل {} تعديلًا من هاتف العامل لتجاوزه الصلاحيات.": "⚠️ {} modification(s) du téléphone de l'employé ignorée(s) car dépassant ses droits.",
  "⚠️ متأخر 2 يومين": "⚠️ En retard de 2 jours",
  "⚠️ متأخر {} {}": "⚠️ En retard de {1} {2}",
  "⚠️ متأخر {} يوم": "⚠️ En retard de {} jour(s)",
  "⚠️ متأخر بـ 2 يومين (موعده يوم {})": "⚠️ En retard de 2 jours (échéance le {})",
  "⚠️ متأخر بـ {} {} (موعده يوم {})": "⚠️ En retard de {1} {2} (échéance le {3})",
  "⚠️ مهلة التصحيح: متبقٍ نحو": "⚠️ Délai de correction : il reste environ",
  "⚠️ مهلة التصحيح: متبقٍ نحو {} ساعة. صحّح ساعة الجهاز أو اتصل بالإنترنت.": "⚠️ Délai de correction : il reste environ {} heure(s). Corrigez l'horloge de l'appareil ou connectez-vous à internet.",
  "⚠️ يتجاوز السقف ({} دج) بـ {} دج": "⚠️ Dépasse le plafond ({} DA) de {} DA",
  "✅ سدد مؤخراً {} دج": "✅ A payé récemment {} DA",
  "✅ مصفّى بالكامل": "✅ Entièrement soldé",
  "✅ ملتزم بالموعد": "✅ Respecte l'échéance",
  "✏️ ملاحظة": "✏️ Note",
  "➕ زيادة دين": "➕ Augmenter la dette",
  "💰 تسديد دين": "💰 Payer une dette",
  "💼 الراتب بعد {} يوم — وقت التحصيل": "💼 Paie dans {} jour(s) — moment de l'encaissement",
  "💼 {} — وقت التحصيل": "💼 {} — moment de l'encaissement",
  "📅 {} — وقت التحصيل": "📅 {} — moment de l'encaissement",
  "📷 مسح QR": "📷 Scanner le QR",
  "🔄 المزامنة": "🔄 Synchroniser",
  "🔒 وضع القراءة فقط: انتهت المهلة. يمكنك عرض البيانات وتصدير نسخة احتياطية. صحّح الساعة واتصل بالإنترنت.": "🔒 Lecture seule : le délai est écoulé. Vous pouvez consulter les données et exporter une sauvegarde. Corrigez l'horloge et connectez-vous à internet.",
  "🔓 رفع الحظر": "🔓 Lever le blocage",
  "🕒 موعد السداد اليوم (يوم {})": "🕒 Échéance aujourd'hui (le {})",
  "🕒 موعده اليوم": "🕒 Échéance aujourd'hui",
  "🖨️ طباعة / حفظ كـ PDF": "🖨️ Imprimer / enregistrer en PDF",
  "🗑️ حذف البيانات": "🗑️ Supprimer les données",
  "🗑️ سلة المهملات": "🗑️ Corbeille",
  "🚨 تجاوز سقف الدين": "🚨 Plafond de dette dépassé",
  "🚨 تجاوز سقف الدين ({} / {} دج)": "🚨 Plafond de dette dépassé ({} / {} DA)",
  "🚨 فوق السقف": "🚨 Au-dessus du plafond",
  "🚫 القائمة السوداء (محظورون من الدين)": "🚫 Liste noire (clients bloqués)",
  "🚫 حساب محظور — لا دين جديد حتى تسديد {} دج": "🚫 Compte bloqué — pas de nouvelle dette avant paiement de {} DA",
  "🚫 حساب محظور — لا يقبل دينًا جديدًا": "🚫 Compte bloqué — n'accepte pas de nouvelle dette",
  "🛍️ سلعة جديدة أخذها الآن (دين جديد يُضاف)": "🛍️ Nouvel article pris maintenant (nouvelle dette ajoutée)"
};

/* ============ Interface language (Arabic default, French optional) + French Centimes Engine ============ */
const DEYN_I18N = (() => {
  const AR = /[\u0600-\u06FF]/;
  const esc = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  let lang = 'ar';
  try { lang = localStorage.getItem('deyn.lang') === 'fr' ? 'fr' : 'ar'; } catch (e) {}
  const exact = new Map(), pats = [];
  let statics = null, built = false;
  const cache = new Map();
  const norm = s => s.replace(/\s+/g, ' ').trim();

  /**
   * Formats a Dinar amount (1 DA = 100 centimes) in natural Algerian French centimes phrasing.
   * Examples:
   *   5 DA     -> "500 centimes"
   *   10 DA    -> "1 000 centimes"
   *   345 DA   -> "34 500 centimes"
   *   10000 DA -> "1 million de centimes"
   *   15000 DA -> "1 million et demi de centimes"
   *   14250 DA -> "1 million et 425 000 centimes"
   */
  function dialectFr(d) {
    const num = Math.round((Number(d) + Number.EPSILON) * 100) / 100;
    if (!(num > 0)) return '';
    const centimes = Math.round(num * 100);
    if (centimes <= 0) return '';
    const fmtC = n => String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, '\u00A0');
    const millions = Math.floor(centimes / 1000000);
    const rem = centimes % 1000000;
    if (millions >= 1) {
      const mStr = millions === 1 ? '1 million' : `${fmtC(millions)} millions`;
      if (rem === 0) return `${mStr} de centimes`;
      if (rem === 500000) return `${mStr} et demi de centimes`;
      return `${mStr} et ${fmtC(rem)} centimes`;
    }
    return `${fmtC(centimes)} centimes`;
  }

  /**
   * Parses any Arabic dialect amount string produced by dialect(d) back into Dinars
   * and converts it into natural French centimes via dialectFr(da).
   */
  const DORO_DA = { 'عشرين دورو': 1, 'ربعين دورو': 2, 'ستين دورو': 3, 'ثمانين دورو': 4 };
  function parseArBase5(part) {
    const s = part.trim();
    if (!s) return null;
    if (s === 'ميادورو') return 5;
    if (s === 'تلاث ميادورو') return 15;
    if (s === 'خمس ميادورو') return 25;
    if (s === 'ألف') return 10;
    if (s === 'ألف ونص') return 15;
    if (s === 'ألفين') return 20;
    if (s === 'ألفين ونص') return 25;
    let m = /^(\d+)\s*(?:آلاف|ألف)(\s+ونص)?$/.exec(s);
    if (m) return Number(m[1]) * 10 + (m[2] ? 5 : 0);
    return null;
  }
  function parseArMillions(part) {
    const s = part.trim();
    if (s === 'مليون') return 10000;
    if (s === 'زوج ملاين') return 20000;
    const m = /^(\d+)\s*(?:ملاين|مليون)$/.exec(s);
    if (m) return Number(m[1]) * 10000;
    return null;
  }
  function arDialectToFr(rawStr) {
    const s = norm(rawStr);
    if (!s) return null;
    if (DORO_DA[s]) return dialectFr(DORO_DA[s]);
    let remDoro = 0;
    let main = s;
    for (const [k, v] of Object.entries(DORO_DA)) {
      if (main.endsWith(' و' + k)) {
        remDoro = v;
        main = main.slice(0, -(' و' + k).length).trim();
        break;
      }
    }
    const b5 = parseArBase5(main);
    if (b5 !== null) return dialectFr(b5 + remDoro);
    if (main.endsWith(' ونص')) {
      const mPart = main.slice(0, -' ونص'.length).trim();
      const mVal = parseArMillions(mPart);
      if (mVal !== null) return dialectFr(mVal + 5000 + remDoro);
    }
    const mDirect = parseArMillions(main);
    if (mDirect !== null) return dialectFr(mDirect + remDoro);
    const wIdx = main.indexOf(' و');
    if (wIdx > 0) {
      const mVal = parseArMillions(main.slice(0, wIdx));
      const tVal = parseArBase5(main.slice(wIdx + 2));
      if (mVal !== null && tVal !== null) return dialectFr(mVal + tVal + remDoro);
    }
    return null;
  }

  function ensureBuilt() {
    if (built) return;
    built = true;
    for (const k of Object.keys(DEYN_FR_DICT)) {
      const v = DEYN_FR_DICT[k];
      if (k.indexOf('{}') >= 0) {
        pats.push({
          re: new RegExp('^' + k.split('{}').map(esc).join('([\\s\\S]*?)') + '$'),
          v,
          n: (k.match(/[\u0600-\u06FF]/g) || []).length,
          len: k.length
        });
      } else {
        exact.set(k, v);
      }
    }
    pats.sort((a, b) => (b.n - a.n) || (b.len - a.len));
    statics = Array.from(exact.keys())
      .filter(k => k.length >= 2)
      .sort((a, b) => b.length - a.length)
      .map(k => ({ re: new RegExp('(?<![\\u0600-\\u06FF])' + esc(k) + '(?![\\u0600-\\u06FF])', 'g'), v: exact.get(k) }));
  }

  function fill(v, groups) {
    let c = 0;
    return v.replace(/\{(\d*)\}/g, (m, i) => {
      const g = groups[i ? +i - 1 : c++];
      return g === undefined ? '' : tr(g);
    });
  }

  const LET = {
    'ا': 'A', 'أ': 'A', 'إ': 'A', 'آ': 'A', 'ٱ': 'A', 'ب': 'B', 'پ': 'P', 'ت': 'T', 'ث': 'Th',
    'ج': 'J', 'چ': 'Ch', 'ح': 'H', 'خ': 'Kh', 'د': 'D', 'ذ': 'Dh', 'ر': 'R', 'ز': 'Z', 'س': 'S',
    'ش': 'Ch', 'ص': 'S', 'ض': 'D', 'ط': 'T', 'ظ': 'Z', 'ع': 'A', 'غ': 'Gh', 'ف': 'F', 'ڤ': 'V',
    'ق': 'Q', 'ك': 'K', 'گ': 'G', 'ل': 'L', 'م': 'M', 'ن': 'N', 'ه': 'H', 'و': 'W', 'ي': 'Y',
    'ى': 'Y', 'ة': 'A', 'ؤ': 'W', 'ئ': 'Y', 'ء': "'"
  };

  function core(t) {
    ensureBuilt();
    const dialFr = arDialectToFr(t);
    if (dialFr) return dialFr;
    if (exact.has(t)) return exact.get(t);
    if (t.length === 1 && LET[t]) return LET[t];
    const k = t.search(AR), rest = k > 0 ? t.slice(k) : null;
    if (rest && exact.has(rest)) return t.slice(0, k) + exact.get(rest);
    if (rest) {
      const restDial = arDialectToFr(rest);
      if (restDial) return t.slice(0, k) + restDial;
    }
    for (const p of pats) {
      let m = p.re.exec(t);
      if (m) return fill(p.v, m.slice(1));
      if (rest) {
        m = p.re.exec(rest);
        if (m) return t.slice(0, k) + fill(p.v, m.slice(1));
      }
    }
    // Check parenthesized dialect inside a string, e.g. "14 250 DA (مليون و425 ألف)"
    let out = t.replace(/\(([^()]*[\u0600-\u06FF][^()]*)\)/g, (full, inner) => {
      const conv = arDialectToFr(inner) || (exact.has(inner.trim()) ? exact.get(inner.trim()) : null);
      return conv ? '(' + conv + ')' : full;
    });
    for (const s of statics) {
      s.re.lastIndex = 0;
      if (s.re.test(out)) {
        s.re.lastIndex = 0;
        out = out.replace(s.re, s.v);
      }
    }
    return out;
  }

  function tr(text) {
    if (lang !== 'fr' || typeof text !== 'string' || !AR.test(text)) return text;
    ensureBuilt();
    const m = /^(\s*)([\s\S]*?)(\s*)$/.exec(text);
    const key = norm(m[2]);
    let r = cache.get(key);
    if (r === undefined) {
      r = core(key);
      if (cache.size > 4000) cache.clear();
      cache.set(key, r);
    }
    return m[1] + r + m[3];
  }

  const ATTRS = ['placeholder', 'title', 'aria-label', 'alt'];
  function node(n) {
    if (!n || lang !== 'fr') return;
    if (n.nodeType === 3) {
      const p = n.parentNode;
      if (p && (p.nodeName === 'SCRIPT' || p.nodeName === 'STYLE' || p.id === 'smsTplAr')) return;
      const v = n.nodeValue;
      if (AR.test(v)) {
        const t = tr(v);
        if (t !== v) n.nodeValue = t;
      }
      return;
    }
    if (n.nodeType !== 1 || n.nodeName === 'SCRIPT' || n.nodeName === 'STYLE') return;
    for (const a of ATTRS) {
      const v = n.getAttribute(a);
      if (v && AR.test(v)) {
        const t = tr(v);
        if (t !== v) n.setAttribute(a, t);
      }
    }
    if (n.nodeName === 'INPUT' && n.type !== 'password' && n.value && AR.test(n.value) && !n.dataset.i18nValDone) {
      ensureBuilt();
      const k = norm(n.value);
      if (exact.has(k)) {
        n.value = exact.get(k);
        n.dataset.i18nValDone = '1';
      }
    }
    for (let c = n.firstChild; c; c = c.nextSibling) node(c);
  }

  function html(s) {
    if (lang !== 'fr' || typeof s !== 'string') return s;
    ensureBuilt();
    return s
      .replace(/>([^<]*[\u0600-\u06FF][^<]*)</g, (m, t) => '>' + tr(t) + '<')
      .replace(/(placeholder|title|aria-label|alt)="([^"]*)"/g, (m, a, v) => a + '="' + tr(v) + '"')
      .replace(/<html[^>]*>/i, '<html lang="fr" dir="ltr">')
      .replace(/dir="rtl"/g, 'dir="ltr"')
      .replace(/direction:\s*rtl/g, 'direction: ltr');
  }

  function installRuntimeHooks() {
    if (typeof window === 'undefined') return;
    // 1. Hook dialect() so all centimes displays work natively in French without hiding them
    if (typeof window.dialect === 'function' && !window.dialect.__i18nWrapped) {
      const origDialect = window.dialect;
      const wrappedDialect = function (d) {
        if (lang === 'fr') return dialectFr(d);
        return origDialect.apply(this, arguments);
      };
      wrappedDialect.__i18nWrapped = true;
      window.dialect = wrappedDialect;
    }
    // 2. Hook toast(), agToast(), deynBanner() so notifications are always translated synchronously
    if (typeof window.toast === 'function' && !window.toast.__i18nWrapped) {
      const origToast = window.toast;
      const wrappedToast = function (m, k) {
        return origToast.call(this, lang === 'fr' ? tr(String(m ?? '')) : m, k);
      };
      wrappedToast.__i18nWrapped = true;
      window.toast = wrappedToast;
    }
    if (typeof window.agToast === 'function' && !window.agToast.__i18nWrapped) {
      const origAgToast = window.agToast;
      const wrappedAgToast = function (m) {
        return origAgToast.call(this, lang === 'fr' ? tr(String(m ?? '')) : m);
      };
      wrappedAgToast.__i18nWrapped = true;
      window.agToast = wrappedAgToast;
    }
    if (typeof window.deynBanner === 'function' && !window.deynBanner.__i18nWrapped) {
      const origBanner = window.deynBanner;
      const wrappedBanner = function (txt, kind) {
        return origBanner.call(this, lang === 'fr' && txt ? tr(String(txt)) : txt, kind);
      };
      wrappedBanner.__i18nWrapped = true;
      window.deynBanner = wrappedBanner;
    }
    // 3. Hook openModal() so every modal's paint() and mount() synchronously translates its DOM
    if (typeof window.openModal === 'function' && !window.openModal.__i18nWrapped) {
      const origOpenModal = window.openModal;
      const wrappedOpenModal = function (render, opts) {
        const m = origOpenModal.call(this, render, opts);
        if (m && m.wrap && lang === 'fr') {
          node(m.wrap);
          if (typeof m.paint === 'function' && !m.paint.__i18nWrapped) {
            const origPaint = m.paint;
            m.paint = function () {
              const r = origPaint.apply(this, arguments);
              if (lang === 'fr') node(m.wrap);
              return r;
            };
            m.paint.__i18nWrapped = true;
          }
        }
        return m;
      };
      wrappedOpenModal.__i18nWrapped = true;
      window.openModal = wrappedOpenModal;
    }
    // 4. Hook statement() so WhatsApp and copied statements are translated in French mode
    if (typeof window.statement === 'function' && !window.statement.__i18nWrapped) {
      const origStatement = window.statement;
      const wrappedStatement = function (c) {
        const s = origStatement.apply(this, arguments);
        if (lang !== 'fr' || typeof s !== 'string') return s;
        return s.split('\n').map(line => tr(line)).join('\n');
      };
      wrappedStatement.__i18nWrapped = true;
      window.statement = wrappedStatement;
    }
    // 5. Hook exportPdfLedger() so both window.open and Blob fallback export French HTML in French mode
    if (typeof window.exportPdfLedger === 'function' && !window.exportPdfLedger.__i18nWrapped) {
      const origExportPdf = window.exportPdfLedger;
      const wrappedExportPdf = function () {
        if (lang !== 'fr') return origExportPdf.apply(this, arguments);
        const origOpen = window.open;
        const origBlob = window.Blob;
        try {
          window.open = function () {
            const w = origOpen.apply(this, arguments);
            if (w && w.document && typeof w.document.write === 'function') {
              const origWrite = w.document.write.bind(w.document);
              w.document.write = function (content) {
                return origWrite(html(String(content ?? '')));
              };
            }
            return w;
          };
          window.Blob = function (parts, options) {
            if (Array.isArray(parts) && options && options.type === 'text/html') {
              parts = parts.map(p => typeof p === 'string' ? html(p) : p);
            }
            return new origBlob(parts, options);
          };
          return origExportPdf.apply(this, arguments);
        } finally {
          window.open = origOpen;
          window.Blob = origBlob;
        }
      };
      wrappedExportPdf.__i18nWrapped = true;
      window.exportPdfLedger = wrappedExportPdf;
      if (typeof window.A === 'object' && window.A) window.A.exportPdf = wrappedExportPdf;
    }
    // 6. Hook renderDisplay, renderPending, renderLedger, renderStats, updateMM so synchronous DOM updates are translated immediately
    for (const fnName of ['renderDisplay', 'renderPending', 'renderLedger', 'renderStats', 'updateMM', 'buildTiles']) {
      if (typeof window[fnName] === 'function' && !window[fnName].__i18nWrapped) {
        const origFn = window[fnName];
        const wrappedFn = function () {
          const r = origFn.apply(this, arguments);
          if (lang === 'fr' && document && document.body) node(document.body);
          return r;
        };
        wrappedFn.__i18nWrapped = true;
        window[fnName] = wrappedFn;
      }
    }
    if (typeof window.A === 'object' && window.A && !window.A.setLang) {
      window.A.setLang = d => set(d && d.l);
    }
    if (typeof window.READONLY_OK !== 'undefined' && window.READONLY_OK && typeof window.READONLY_OK.add === 'function') {
      window.READONLY_OK.add('setLang');
    }
  }

  function start() {
    ensureBuilt();
    installRuntimeHooks();
    if (lang !== 'fr') return;
    document.documentElement.lang = 'fr';
    document.documentElement.dir = 'ltr';
    if (document.title && AR.test(document.title)) document.title = tr(document.title);
    document.body.classList.add('fr');
    if (!document.getElementById('deyn-fr-rtl-ltr-style')) {
      const st = document.createElement('style');
      st.id = 'deyn-fr-rtl-ltr-style';
      st.textContent = [
        'html,body{direction:ltr!important}',
        'body.fr *{direction:ltr!important}',
        'body.fr [style*="text-align:right"]{text-align:left!important}',
        'body.fr .nt,body.fr .pick,body.fr .cmp th,body.fr .cmp td,body.fr .tape.empty{text-align:left!important}',
        'body.fr .modesw .thumb{right:auto!important;left:4px!important}',
        'body.fr .modesw[data-mode=calc] .thumb{transform:translateX(100%)!important}',
        'body.fr .sw i::after{right:auto!important;left:3px!important}',
        'body.fr .sw input:checked+i::after{transform:translateX(20px)!important}',
        'body.fr .rk-go,body.fr .nt-go{transform:scaleX(-1);display:inline-block}',
        'body.fr .tile .t-tag{font-size:8.5px;padding:1px 5px;max-width:96%;overflow:hidden;text-overflow:ellipsis}',
        'body.no-dial .hx-dial,body.no-dial .kp-d,body.no-dial .rk-d,body.no-dial .ds-d,body.no-dial .dial,body.no-dial #dial,body.no-dial .t-tag,body.no-dial .pill:not(.bk){display:none!important}'
      ].join('');
      document.head.appendChild(st);
    }
    if (typeof window.buildTiles === 'function' && typeof window.S !== 'undefined' && window.S) {
      try { window.buildTiles(); window.renderAll(); } catch (e) {}
    }
    node(document.body);
    new MutationObserver(ms => {
      for (const m of ms) {
        if (m.type === 'childList') m.addedNodes.forEach(node);
        else if (m.type === 'characterData') node(m.target);
        else if (m.type === 'attributes') node(m.target);
      }
    }).observe(document.body, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ATTRS });
  }

  function set(l) {
    try { localStorage.setItem('deyn.lang', l === 'fr' ? 'fr' : 'ar'); } catch (e) {}
    location.reload();
  }

  return {
    tr,
    html,
    start,
    set,
    translateRoot: node,
    dialectFr,
    arDialectToFr,
    get lang() { return lang; },
    get locale() { return lang === 'fr' ? 'fr-FR' : 'ar-DZ'; }
  };
})();
(function () {
  var b = document.getElementById('agLang');
  if (b) {
    b.textContent = DEYN_I18N.lang === 'fr' ? 'AR' : 'Français';
    b.setAttribute('aria-label', DEYN_I18N.lang === 'fr' ? 'Arabe' : 'Français');
    b.onclick = function () { DEYN_I18N.set(DEYN_I18N.lang === 'fr' ? 'ar' : 'fr'); };
  }
  DEYN_I18N.start();
})();
