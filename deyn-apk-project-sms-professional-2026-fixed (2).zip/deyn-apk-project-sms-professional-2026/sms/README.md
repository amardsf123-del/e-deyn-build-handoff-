# DEYN SMS reminders & Complete French Localization

The app's actual source is stored in `deyn-apk-project.zip` (and updated idempotently by `.github/scripts/integrate_sms.py`).

## Fixed SMS Architecture (Per-Part Tracking & Delivery States)

- **Per-Part `PendingIntent` + `BroadcastReceiver` (`DeynSmsPlugin$SmsStatusReceiver`)**:
  - Single-part messages use `SmsManager.sendTextMessage(...)` and multi-part messages use `SmsManager.sendMultipartTextMessage(...)` with a dedicated `sentIntent` (`com.deyn.app.SMS_SENT`) and `deliveryIntent` (`com.deyn.app.SMS_DELIVERED`) for **every individual segment**.
  - Dual-SIM devices resolve the active default SMS subscription via `SmsManager.getDefaultSmsSubscriptionId()` / `createForSubscriptionId(subId)` so multipart UDH concatenation references stay consistent across all parts.
- **Strict State Separation (Never Prematurely Marked Sent)**:
  - `attempting`: Dispatch attempt durably recorded before invoking Android API.
  - `accepted_by_android`: Android `SmsManager` accepted the API call; awaiting radio confirmation for all parts (`sent = false`).
  - `sent_to_network`: Every part (`partsSent == partsTotal && partsFailed == 0`) received `Activity.RESULT_OK` from the cellular radio (`sent = true`).
  - `delivered`: Carrier delivery receipt (`ACTION_SMS_DELIVERED` PDU status `0`) confirmed for all parts (`delivered = true`).
  - `partial_failure`: At least one part succeeded and at least one part failed (`partsSent > 0 && partsFailed > 0`). Explicitly flagged as partial failure (`sent = false`), never as full success.
  - `failed`: Zero parts reached the network (`partsSent == 0 && partsFailed > 0`). Claim is released so `WorkManager` or manual retry can re-send cleanly without duplication.
  - `dispatch_uncertain`: Stale in-flight claim after an unexpected process termination; suppressed from automatic re-sending to prevent duplicates.
- **Reboot Survival (`DeynSmsPlugin$SmsBootReceiver`)**:
  - Persists `active_queue_json` in `SharedPreferences` and listens for `BOOT_COMPLETED` and `MY_PACKAGE_REPLACED` to restore pending scheduled reminders in `WorkManager` using canonical unique work names (`deyn_sms_<id>` and `deyn_sms_deferred_<id>`).

## Complete French Localization & Centimes (`sms/i18n.js`)

- Translates all static and dynamic screens, modals, placeholders, toasts, customer statements, and printable PDF exports into professional French with zero remaining Arabic UI text when `Français` is active.
- Restores the Centimes feature in French mode (`Affichage des montants en centimes`) via `DEYN_I18N.dialectFr` and `DEYN_I18N.arDialectToFr` (`500 centimes`, `1 000 centimes`, ..., `200 000 centimes`, `1 million de centimes`, `1 million et demi de centimes`, etc.) across the Quick Calculator tiles, main display, customer cards, statistics, modals, trash, and PDF ledger.
